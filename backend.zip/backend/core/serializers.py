from rest_framework import serializers
from .models import EquipmentFile

class EquipmentFileSerializer(serializers.ModelSerializer):
    class Meta:
        model = EquipmentFile
        fields = '__all__'