from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from .models import EquipmentFile
from .serializers import EquipmentFileSerializer
import pandas as pd
import os
from django.conf import settings

class UploadFileView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        file_serializer = EquipmentFileSerializer(data=request.data)
        if file_serializer.is_valid():
            file_serializer.save()
            return Response(file_serializer.data, status=201)
        return Response(file_serializer.errors, status=400)

class RecentFilesView(APIView):
    def get(self, request):
        files = EquipmentFile.objects.order_by('-uploaded_at')[:5]
        serializer = EquipmentFileSerializer(files, many=True)
        return Response(serializer.data)

class DataAnalysisView(APIView):
    def get(self, request, file_id):
        try:
            obj = EquipmentFile.objects.get(id=file_id)
            file_path = os.path.join(settings.MEDIA_ROOT, str(obj.file))
            
            # Read CSV
            df = pd.read_csv(file_path)

            # 1. Summary Statistics
            total_count = len(df)
            
            # Clean numeric data for averages
            numeric_cols = ['Flowrate', 'Pressure', 'Temperature']
            averages = df[numeric_cols].mean().to_dict()

            # 2. Distribution for Charts (Group by Equipment Type)
            type_dist = df['Type'].value_counts().to_dict()

            return Response({
                "filename": obj.file.name,
                "total_count": total_count,
                "averages": averages,
                "type_distribution": type_dist,
                "raw_data": df.head(20).to_dict(orient='records') 
            })
        except Exception as e:
            return Response({"error": str(e)}, status=500)