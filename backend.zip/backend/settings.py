import os

INSTALLED_APPS = [
    # ... default apps ...
    'rest_framework',
    'corsheaders',
    'core',
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware', # Add this at the top
    'django.middleware.security.SecurityMiddleware',
    # ... others ...
]

# Allow React (Port 3000) to talk to Django
CORS_ALLOWED_ORIGINS = ["http://localhost:3000"]

# Media Configuration for CSV uploads
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')