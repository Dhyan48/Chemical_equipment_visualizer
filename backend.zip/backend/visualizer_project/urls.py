from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from core.views import UploadFileView, DataAnalysisView, RecentFilesView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/upload/', UploadFileView.as_view()),
    path('api/history/', RecentFilesView.as_view()),
    path('api/analyze/<int:file_id>/', DataAnalysisView.as_view()),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)