import sys
import requests
from PyQt5.QtWidgets import (QApplication, QMainWindow, QPushButton, QVBoxLayout, 
                             QWidget, QFileDialog, QLabel, QHBoxLayout)
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt

API_URL = "http://127.0.0.1:8000/api"

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Chemical Equipment Visualizer (Desktop)")
        self.setGeometry(100, 100, 1000, 700)

        # Main Layout
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.layout = QVBoxLayout(self.central_widget)

        # Controls
        btn_layout = QHBoxLayout()
        self.btn_upload = QPushButton("Upload CSV")
        self.btn_upload.clicked.connect(self.upload_file)
        btn_layout.addWidget(self.btn_upload)
        
        self.lbl_status = QLabel("Ready")
        btn_layout.addWidget(self.lbl_status)
        self.layout.addLayout(btn_layout)

        # Plot Area (Matplotlib)
        self.figure, self.ax = plt.subplots()
        self.canvas = FigureCanvas(self.figure)
        self.layout.addWidget(self.canvas)

    def upload_file(self):
        fname, _ = QFileDialog.getOpenFileName(self, 'Open CSV', '.', "CSV Files (*.csv)")
        if fname:
            self.lbl_status.setText("Uploading...")
            files = {'file': open(fname, 'rb')}
            try:
                # 1. Upload to Django
                response = requests.post(f"{API_URL}/upload/", files=files)
                if response.status_code == 201:
                    file_id = response.json()['id']
                    self.fetch_analysis(file_id)
                else:
                    self.lbl_status.setText("Upload Failed")
            except Exception as e:
                self.lbl_status.setText(f"Error: {e}")

    def fetch_analysis(self, file_id):
        self.lbl_status.setText("Analyzing...")
        try:
            # 2. Get Data from Django
            response = requests.get(f"{API_URL}/analyze/{file_id}/")
            data = response.json()
            self.update_charts(data)
            self.lbl_status.setText(f"Showing data for: {data['filename']}")
        except Exception as e:
            self.lbl_status.setText(f"Analysis Error: {e}")

    def update_charts(self, data):
        """
        Modified function to show a Pie Chart with Percentages
        """
        self.ax.clear()
        
        # Extract data for plotting
        types = list(data['type_distribution'].keys())
        counts = list(data['type_distribution'].values())

        # --- PIE CHART CONFIGURATION ---
        # autopct='%1.1f%%' adds the percentage labels automatically
        # startangle=90 makes it look neater
        colors = ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#c2c2f0']
        
        self.ax.pie(counts, 
                    labels=types, 
                    autopct='%1.1f%%', 
                    startangle=90, 
                    colors=colors[:len(types)]) # Ensure we have enough colors
        
        self.ax.set_title('Equipment Type Distribution')
        self.ax.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.
        
        # Refresh Canvas
        self.canvas.draw()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())