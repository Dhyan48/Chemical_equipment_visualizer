import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Bar, Pie } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement } from 'chart.js';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

function App() {
  const [file, setFile] = useState(null);
  const [data, setData] = useState(null);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    const res = await axios.get('http://127.0.0.1:8000/api/history/');
    setHistory(res.data);
  };

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append('file', file);
    try {
      const res = await axios.post('http://127.0.0.1:8000/api/upload/', formData);
      analyzeData(res.data.id);
      fetchHistory();
    } catch (err) {
      alert("Upload Failed");
    }
  };

  const analyzeData = async (id) => {
    const res = await axios.get(`http://127.0.0.1:8000/api/analyze/${id}/`);
    setData(res.data);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h1>Chemical Parameter Visualizer</h1>
      
      {/* Upload Section */}
      <div style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px' }}>
        <h3>Upload New Dataset</h3>
        <input type="file" onChange={(e) => setFile(e.target.files[0])} />
        <button onClick={handleUpload} disabled={!file}>Upload & Analyze</button>
      </div>

      {/* History Section */}
      <div style={{ marginBottom: '20px' }}>
        <h3>Recent Uploads (History)</h3>
        {history.map(h => (
          <button key={h.id} onClick={() => analyzeData(h.id)} style={{marginRight: '10px'}}>
            ID: {h.id} ({new Date(h.uploaded_at).toLocaleTimeString()})
          </button>
        ))}
      </div>

      {/* Visualization Section */}
      {data && (
        <div style={{ display: 'flex', gap: '20px' }}>
          <div style={{ width: '50%' }}>
            <h3>Equipment Type Distribution</h3>
            <Pie data={{
              labels: Object.keys(data.type_distribution),
              datasets: [{
                data: Object.values(data.type_distribution),
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0']
              }]
            }} />
          </div>
          
          <div style={{ width: '50%' }}>
            <h3>Average Parameters</h3>
            <Bar data={{
              labels: Object.keys(data.averages),
              datasets: [{
                label: 'Average Value',
                data: Object.values(data.averages),
                backgroundColor: 'rgba(75, 192, 192, 0.5)',
              }]
            }} />
          </div>
        </div>
      )}
      
      {/* Data Table */}
      {data && (
        <div style={{ marginTop: '30px' }}>
            <h3>Raw Data Preview</h3>
            <table border="1" cellPadding="5" style={{width: '100%', borderCollapse: 'collapse'}}>
                <thead>
                    <tr>{Object.keys(data.raw_data[0]).map(k => <th key={k}>{k}</th>)}</tr>
                </thead>
                <tbody>
                    {data.raw_data.map((row, i) => (
                        <tr key={i}>{Object.values(row).map((val, j) => <td key={j}>{val}</td>)}</tr>
                    ))}
                </tbody>
            </table>
        </div>
      )}
    </div>
  );
}

export default App;